<?PHP
$conn=new mysqli("localhost","root","","cdo");
?>