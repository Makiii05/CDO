<?php
session_start();

$name = $_SESSION["name"];
$email = $_SESSION["email"];
require("../conn.php");

if (empty($id)) {
    header("Location: ../index.php?Error=" . urlencode("Session Expired. "));
    exit();
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    //--------------------------------------------ADD & Update PRODUCT-----------------------------------
    if (isset($_POST['addProduct'])) {
        $prodname = $_POST["prodname"];
        $prodprice = $_POST["prodprice"];
        $proddesc = $_POST["proddesc"];
        $prodquan = $_POST["prodquan"];

        $uploadDir = '../pics/';
        $prodimage = $_FILES['prodimage']['name'];
        $uploadFile = $uploadDir . basename($prodimage);

        if (move_uploaded_file($_FILES['prodimage']['tmp_name'], $uploadFile)) {
            try {
                $conn->begin_transaction();
                // Check if product exists
                $stmt = $conn->prepare("SELECT * FROM tblproduct WHERE prodname = ?");
                $stmt->bind_param("s", $prodname);
                $stmt->execute();
                $result = $stmt->get_result();
                $rowCount = $result->num_rows;

                //--------------------------------------------Update PRODUCT-----------------------------------                
                if ($rowCount == 1) {
                    $row = $result->fetch_assoc();
                    $newQuan = $row["prodquan"] + $prodquan;

                    // Prepare the UPDATE query
                    $stmt = $conn->prepare("UPDATE tblproduct 
                                            SET prodprice = ?, proddesc = ?, prodquantity = ?, prodimage = ? 
                                            WHERE prodname = ?");
                    $stmt->bind_param("ssiss", $prodprice, $proddesc, $newQuan, $prodimage, $prodname);

                    if ($stmt->execute()) {
                        header("location:../html/a_home.php?Successful");
                    } else {
                        throw new Exception('Error updating product.');
                    }
                } else {
                    //--------------------------------------------ADD PRODUCT----------------------------------- 
                    // Insert the new product (Prepared Statement)
                    $stmt = $conn->prepare("INSERT INTO tblproduct (prodname, prodprice, proddesc, prodquantity, prodimage) 
                                            VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssis", $prodname, $prodprice, $proddesc, $prodquan, $prodimage);

                    if ($stmt->execute()) {
                        header("location:../html/a_home.php?Successful");
                    } else {
                        throw new Exception('Error adding product.');
                    }
                }
                $conn->commit();  // Commit changes
                exit();
            } catch (Exception $e) {
                $conn->rollback();
                error_log($e->getMessage());
                header("location:../html/a_home.php?Error=" . urlencode($e->getMessage()));
                exit();
            }
        } else {
            header("location:../html/a_home.php?Error=" . urlencode('Error uploading the image.'));
            exit();
        }
    }
}
