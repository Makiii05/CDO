<?php
require("../conn.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    //---------------------------------------------------LOGIN------------------------------------------
    if (isset($_GET["login"])) {
        $email = $_GET["InEmail"];
        $pass = $_GET["InPass"];

        try {
            $conn->begin_transaction();

            $stmt = $conn->prepare("SELECT * FROM tblaccount WHERE fldemail = ? AND fldpassword = ?");
            $stmt->bind_param("ss", $email, $pass);
            $stmt->execute();
            $result = $stmt->get_result();
            $rowCount = $result->num_rows;

            if ($rowCount == 1) {
                session_start();
                $row = $result->fetch_assoc();
                $_SESSION["id"] = $row['ID'];
                $_SESSION["name"] = $row['fldname'];
                $_SESSION["email"] = $row['fldemail'];
                $_SESSION["position"] = $row['fldposition'];

                if ($row['fldposition'] == 'admin') {
                    header("Location:../html/a_home.php");
                } else {
                    header("Location:../html/c_home.php");
                }
            } else {
                header("Location:../index.php?Invalid");
            }

            $conn->commit();
        } catch (Exception $e) {
            $conn->rollback();
            error_log($e->getMessage());
            header("Location:../index.php?Error");
        }
    }
    //---------------------------------------------------SIGNUP------------------------------------------
    elseif (isset($_GET["signup"])) {
        $name = $_GET["UpName"];
        $email = $_GET["UpEmail"];
        $pass = $_GET["UpPass"];

        $houseNo = isset($_GET["hnum"]) ? $_GET["hnum"] : "";
        $barangay = isset($_GET["brgy"]) ? $_GET["brgy"] : "";
        $city = isset($_GET["city"]) ? strtolower(trim($_GET["city"])) : "";
        $province = isset($_GET["province"]) ? strtolower(trim($_GET["province"])) : "";

        // validate the city and province
        $isValidCity = ($city === "lipa" || $city === "lipa city");
        $isValidProvince = ($province === "batangas");

        if (!$isValidCity || !$isValidProvince) {
            header("location:../html/signup.php?LocationError");
            exit();
        }

        $city = "Lipa City";
        $province = "Batangas";

        // Combine address components
        $fullAddress = trim(implode(", ", array_filter([
            $houseNo,
            $barangay,
            $city,
            $province
        ])));

        try {
            $conn->begin_transaction();

            $stmt = $conn->prepare("SELECT * FROM tblaccount WHERE fldemail = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $rowCount = $result->num_rows;

            if ($rowCount == 0) {
                $stmt = $conn->prepare("INSERT INTO tblaccount (fldname, fldemail, fldpassword, fldposition, fldaddress) VALUES (?, ?, ?, 'customer', ?)");
                $stmt->bind_param("ssss", $name, $email, $pass, $fullAddress);
                $stmt->execute();
                header("location:../html/signup.php?Successful");
            } else {
                header("location:../html/signup.php?Existing");
            }

            $conn->commit();
        } catch (Exception $e) {
            $conn->rollback();
            error_log($e->getMessage());
            header("location:../html/signup.php?Error");
        }
    }
}
