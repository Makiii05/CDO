<?PHP
session_start();
$id = $_SESSION["id"];
$position = $_SESSION['position'];
$name = $_SESSION["name"];
$email = $_SESSION["email"];
require("../conn.php");
require("components/a_header.php");
require("components/modal.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CDO Foodsphere E-Cart</title>
    <link rel="stylesheet" href="../css/myProf_Orders.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        body {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('../pics/bg.png');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            min-height: 100vh;
        }
    </style>
</head>

<body>
    <!-- ---------------------------------------ORDER_AREA----------------------------- -->
        <div class="container-fluid">
            <div class="container-fluid bg-light bg-opacity-75 p-3 rounded">
                <div class="row d-flex" style="min-height: 350px;">
                <!-------------------SIDEBAR--------------->
                    <div class="col-3 d-flex flex-column">
                        <div class="sidebar bg-success text-light rounded ps-1 py-2 flex-grow-1">
                            <div class="d-flex align-items-center mb-3">
                                <div class="col-3 p-0 prof" style="width: 50px; height: 50px;">
                                    <div class="rounded-circle bg-light" style="width: 100%; height: 100%;"><?PHP /* echo $prof */?></div>
                                </div>
                                <span class="profile-name ms-2"><?PHP echo $_SESSION['name'] ?></span>
                            </div>
                            <hr>
                            <ul class="nav flex-column">
                                <li class="nav-item mb-2">
                                    <a href="a_prof.php" class="nav-link text-light">
                                        <i class="bi bi-person-circle me-2"></i>
                                        <span>My Profile</span>
                                    </a>
                                </li>
                                <li class="nav-item mb-2">
                                    <a href="orders.php" class="nav-link text-light active">
                                        <i class="bi bi-card-checklist me-2"></i>
                                        <span>Orders</span>
                                    </a>
                                </li>
                                <li class="nav-item mb-2">
                                    <a href="inventory.php" class="nav-link text-light">
                                        <i class="bi bi-truck me-2"></i>
                                        <span>Inventory</span>
                                    </a>
                                </li>
                                <li class="nav-item mb-2">
                                    <a href="reports.php" class="nav-link text-light">
                                        <i class="bi bi-flag me-2"></i>
                                        <span>Reports</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                <!-------------------CONTENT CONTAINER--------------->
                    <div class="col-9">
                        <div class="content bg-white rounded p-3 pb-5">
                            <h2 class="p-3">Customer's Orders</h2>
                            <hr>
                            <div class="px-md-5 px-2">
                                <nav>
                                    <div class="nav nav-tabs row" id="nav-tab" role="tablist">
                                        <button class="nav-link navorder text-secondary active col-md" id="nav-list-tab" data-bs-toggle="tab" data-bs-target="#nav-list" type="button" role="tab" aria-controls="nav-list" aria-selected="true">LIST</button>
                                        <button class="nav-link navorder text-secondary col-md" id="nav-toShip-tab" data-bs-toggle="tab" data-bs-target="#nav-toShip" type="button" role="tab" aria-controls="nav-toShip" aria-selected="false">TO SHIP</button>
                                        <button class="nav-link navorder text-secondary col-md" id="nav-complete-tab" data-bs-toggle="tab" data-bs-target="#nav-complete" type="button" role="tab" aria-controls="nav-complete" aria-selected="false">COMPLETED</button>
                                    </div>
                                </nav>
                            </div>
                            <div class="tab-content px-md-4 px-2" id="nav-tabContent">
                                <div class="tab-pane fade show active p-3" id="nav-list" role="tabpanel" aria-labelledby="nav-list-tab">
                                    <div class="table-responsive">
                                        <table id="tableUsers" class="table table-striped" style="width: 850px;">
                                            Hi
                                        </table>
                                    </div>
                                </div>

                                <div class="tab-pane fade p-3" id="nav-toShip" role="tabpanel" aria-labelledby="nav-toShip-tab">
                                    <div class="table-responsive">
                                        <table id="tableUsers" class="table table-striped" style="width: 850px;">
                                            Hi
                                        </table>
                                    </div>
                                </div>

                                <div class="tab-pane fade p-3" id="nav-complete" role="tabpanel" aria-labelledby="nav-complete-tab">
                                    <div class="table-responsive">
                                        <table id="tableUsers" class="table table-striped" style="width: 850px;">
                                            Hi
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</body>
<script>
    <?php
        if (isset($_GET["Successful"])) {
            echo "setTimeout(Hello, 250); function Hello() { alert('Profile Updated Successfully.'); }";
        } elseif (isset($_GET["Error"])) {
            $errorMessage = urldecode($_GET["Error"]);
            echo "setTimeout(Hello, 250); function Hello() { alert('An Error occurred: " . $errorMessage . "'); }";
        }
    ?>
</script>
</html>