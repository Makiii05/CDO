<?PHP
echo"
<div class='d-flex'>
<input class='w-25 rounded-0 bg-dark bg-opacity-75 border-0 text-light' type='button' value='-' onclick='minusQuan()'>
<input class='border-0 text-center' type='number' id='quan' name=quan style='width: 40px;' required min='1' max='$row[prodquantity]' value='1'><br>
<input class='w-25 rounded-0 bg-dark bg-opacity-75 border-0 text-light' type='button' value='+' onclick='plusQuan()'>
</div>
";
?>