<?php include('prodinfo.php'); ?>
<div class="modal fade" id="modalMsg" tabindex="-1" aria-labelledby="modalMsgLabel" aria-hidden="true">
    <form action="../sql/home.php" method="get">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalMsgLabel">Message Seller</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <iframe src="" frameborder="0"></iframe>
                </div>
                <div class="modal-footer justify-content-center">
                    <input type="text" placeholder="Type a messages..." class="form-control" style="width: 90%;" required>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-send-fill"></i></button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php include('prodinfo.php'); 
    while ($row = $prodlist->fetch_assoc()) {
        echo "
        <div class='modal fade' id='$row[prodid]' tabindex='-1'>
            <form action='../sql/home.php' method='post' enctype='multipart/form-data'>
                <div class='modal-dialog modal-md'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <h5 class='modal-title' id='modalMsgLabel'>UPDATE PRODUCT</h5>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                        </div>
                        <div class='modal-body'>
                            <input type='text' name='prodname' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' value='$row[prodname]' required>
                            <input type='text' name='prodprice' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' value='$row[prodprice]' required>
                            <input type='text' name='proddesc' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' value='$row[proddesc]' required>
                            <input type='text' name='prodquan' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' value='$row[prodquantity]' required>
                            <label class='ps-2 m-2'>Product Image</label>
                            <input type='file' name='prodimage' class='form-control' accept='.png, .jpg, .jpeg'>
                        </div>
                        <div class='modal-footer justify-content-ends'>
                            <button type='submit' name='updProduct' class='btn border-1 border-danger text-danger rounded-pill'><b>UPDATE PRODUCT</b></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        ";
}
?>
<?php include('prodinfo.php'); ?>
<div class='modal fade' id='modalAddNew' tabindex='-1' aria-labelledby='modalAddLabel' aria-hidden='true'>
    <form action='../sql/home.php' method='post' enctype='multipart/form-data'>
        <div class='modal-dialog modal-md'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <h5 class='modal-title' id='modalMsgLabel'>ADD NEW PRODUCT</h5>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                </div>
                <div class='modal-body'>
                    <input type='text' name='prodname' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Name' required>
                    <input type='text' name='prodprice' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Price' required>
                    <input type='text' name='proddesc' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Description' required>
                    <input type='text' name='prodquan' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Quantity' required>
                    <label class='ps-2 m-2'>Product Image</label>
                    <input type='file' name='prodimage' class='form-control' accept='.png, .jpg, .jpeg' required>
                </div>
                <div class='modal-footer justify-content-ends'>
                    <button type='submit' name='addProduct' class='btn border-1 border-danger text-danger rounded-pill'><b>ADD PRODUCT </b></button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php include('prodinfo.php'); ?>
<div class='modal fade' id='modalAddExist' tabindex='-1'>
    <form action='../sql/home.php' method='post' enctype='multipart/form-data'>
        <div class='modal-dialog modal-md'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <h5 class='modal-title' id='modalMsgLabel'>ADD PRODUCT DELIVERY</h5>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                </div>
                <div class='modal-body'>
                    <input type='date' name='date' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' value="<?PHP echo date("Y-m-d"); ?>" required>
                    <select name="prodname"  class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-select'>
                        <?PHP
                        if($prodlist->num_rows == 0){
                            echo "<option value='null'>Currently No Product Listed</option>";
                        }else{
                            while($row=$prodlist->fetch_assoc()){
                                echo "<option value='$row[prodname]'>$row[prodname]</option>";
                            }
                        }
                        ?>
                    </select>
                    <input type='number' name='prodquan' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Quantity' required>
                    <input type='text' name='proddesc' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Description' required>
                </div>
                <div class='modal-footer justify-content-ends'>
                    <button type='submit' name='addDelivery' class='btn border-1 border-danger text-danger rounded-pill'><b>ADD PRODUCT</b></button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php include('prodinfo.php'); ?>
<div class='modal fade' id='modalAddWaste' tabindex='-1'>
    <form action='../sql/home.php' method='post' enctype='multipart/form-data'>
        <div class='modal-dialog modal-md'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <h5 class='modal-title' id='modalMsgLabel'>ADD PRODUCT DELIVERY</h5>
                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                </div>
                <div class='modal-body'>
                    <input type='date' name='date' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' value="<?PHP echo date("Y-m-d"); ?>" required>
                    <select name="prodname"  class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-select'>
                        <?PHP
                        if($prodlist->num_rows == 0){
                            echo "<option value='null'>Currently No Product Listed</option>";
                        }else{
                            while($row=$prodlist->fetch_assoc()){
                                echo "<option value='$row[prodname]'>$row[prodname]</option>";
                            }
                        }
                        ?>
                    </select>
                    <input type='number' name='prodquan' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Quantity' required>
                    <input type='text' name='proddesc' class='bg-0 pb-2 mb-4 rounded-0 border-0 border-bottom form-control' placeholder='Product Description' required>
                </div>
                <div class='modal-footer justify-content-ends'>
                    <button type='submit' name='addWastages' class='btn border-1 border-danger text-danger rounded-pill'><b>ADD WASTAGES</b></button>
                </div>
            </div>
        </div>
    </form>
</div>