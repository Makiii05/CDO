<?PHP
//INFO of all product
$prodlist = $conn->query("SELECT * FROM tblproduct");

$prodInv  = $conn->query("SELECT * FROM tblinventory");
$prodInvWaste  = $conn->query("SELECT * FROM tblinventory where fldstatus='wastages'");
$prodInvDel  = $conn->query("SELECT * FROM tblinventory where fldstatus='delivery'");
?>