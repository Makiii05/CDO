<?PHP
session_start();
require("../conn.php");
require("components/c_header.php");
require("components/modal.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CDO Foodsphere E-Cart</title>
    <link rel="stylesheet" href="../css/Auth.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        body {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('../pics/bg.png');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            min-height: 100vh;
        }
    </style>
</head>

<body>
    <!-- ---------------------------------------PRODUCT LIST--------------------------- -->
    <div class="container-fluid">
        <div class="my-5 text-center">
            <h1 class="display-4 fw-bold" style="color: #FF4500; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">OUR PRODUCTS</h1>
            <p class="lead text-light" style="text-shadow: 1px 1px 2px rgba(0,0,0,0.7);">Our delicious home-style food creations allow people to indulge and taste the comfort of home anytime, anywhere.</p>
        </div>
        <div class="container-fluid bg-light bg-opacity-75 p-5 rounded text-center">
            <h2 class="mb-4">Featured Products</h2>
            <div class="row">
                <?PHP
                $result = $conn->query("SELECT * FROM tblproduct");
                while ($row = $result->fetch_assoc()) {
                    echo "
                        <div class='col-md-3 mb-3 '>
                        <a class='text-decoration-none' href='item.php?product=$row[prodname]'>
                            <div class='card'><!--item-->
                                <div class='card-body' style='height: 200px;'>
                                    <div class='h-75'>
                                        <img src='../pics/$row[prodimage]' style='width: 100px;' class='card-img-top'>                                
                                    </div>
                                    <div class='row h-25'>
                                        <h6 class='card-title text-start'>$row[prodname]</h6>
                                        <small class='col-6 text-start'>P $row[prodprice]</small>
                                        <small class='col-6 text-end'>Stock: $row[prodquantity]</small>
                                    </div>
                                </div>
                            </div>
                        </a>
                        </div>
                        ";
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>