<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CDO Foodsphere E-Cart</title>
    <link rel="stylesheet" href="../css/Auth.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>

<body>
    <div class="parent row m-0">
        <div class="box col-lg-5 p-5">
            <h1 class="text-danger font-weight-bold mb-3">Be a part of the CDO Community!</h1>
            <div class="bg-light p-4 pb-3 rounded-3 shadow">
                <h3 class="text-center">SIGN UP</h3><br>
                <form class="form-group" action="../sql/userAuth.php" method="get">
                    <input class="form-control mb-3 p-2 bg-light rounded-0 border-dark border-0 border-bottom" type="text" name="UpName" placeholder="Full name (Lastname, Firstname MI)" required>

                    <input class="form-control mb-3 p-2 bg-light rounded-0 border-dark border-0 border-bottom" type="email" name="UpEmail" placeholder="Email Address" required>

                    <div class="d-flex mb-3">
                        <a class="text-secondary form-select p-2 bg-light rounded-0 border-dark border-0 border-bottom text-decoration-none" data-bs-toggle="collapse" href="#addAddress" role="button" aria-expanded="false" aria-controls="addAddress">
                            <span>Add Address</span>
                        </a>
                    </div>

                    <div class="collapse" id="addAddress">
                        <div class="card card-body">
                            <div class="d-flex align-items-center mb-2">
                                <b class="me-2">Add Address</b>
                                <div class="dropdown-center">
                                    <a class="remBut d-flex text-black align-items-center" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="bi bi-question-circle fs-6 text-danger"></i>
                                    </a>
                                    <ul class="reminder dropdown-menu p-2">
                                        <small>
                                            <font color="red">Reminder!</font><br>Use the existing product name to update the information about the product.
                                        </small>
                                    </ul>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4"><input class="form-control mb-3 p-2 bg-none rounded-0 border-dark border-0 border-bottom" type="number" name="hnum" placeholder="House No."></div>
                                <div class="col-md-8"><input class="form-control mb-3 p-2 bg-none rounded-0 border-dark border-0 border-bottom" type="text" name="brgy" placeholder="Barangay" required></div>
                                <div class="col-12"><input class="form-control mb-3 p-2 bg-none rounded-0 border-dark border-0 border-bottom" type="text" name="city" placeholder="City/ Municipality" required></div>
                                <div class="col-12"><input class="form-control mb-3 p-2 bg-none rounded-0 border-dark border-0 border-bottom" type="text" name="province" placeholder="Province" required></div>
                            </div>
                        </div>
                    </div>

                    <input class="form-control mb-3 p-2 bg-light rounded-0 border-dark border-0 border-bottom" type="password" name="UpPass" placeholder="Password" required>

                    <input class="form-control mb-3 p-2 bg-light rounded-0 border-dark border-0 border-bottom" type="password" name="UpCPass" placeholder="Confirm Password" required onchange="cpass()">

                    <small class="ps-1" style="font-size: clamp(12px,2vw,14px);">Have an account? <a href="../index.php">Log In</a>.</small><br><br><br>

                    <input class="form-control rounded-5 border-2 border-danger text-danger bg-light fs-5 button" type="submit" name="signup" value="S I G N   U P" disabled>
                </form>

            </div>
        </div>
        <div class="pic col-lg-7 p-0">
            <div class="bg-dark bg-opacity-50 m-0" style="height: 100%; width: 100%;"></div>
        </div>
    </div>
</body>
<script>
    toastr.options = {
        "closeButton": true,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "timeOut": "10000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    <?PHP
    if (isset($_GET["Successful"])) {
        echo "toastr.success('Account registered.');";
    } elseif (isset($_GET["Existing"])) {
        echo "toastr.info('Account Already Exist.');";
    } elseif (isset($_GET["LocationError"])) {
        echo "toastr.warning('Address Out of Service Coverage (Lipa City Batangas)');";
    }
    ?>

    function cpass() {
        var pass = document.querySelector('input[name="UpPass"]');
        var cpass = document.querySelector('input[name="UpCPass"]');
        var submitButton = document.querySelector('input[type="submit"]');

        if (cpass.value === pass.value && cpass.value !== "") {
            submitButton.disabled = false;
        } else {
            submitButton.disabled = true;
        }
    }
</script>

</html>