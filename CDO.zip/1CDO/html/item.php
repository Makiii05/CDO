<?PHP
session_start();
$id = $_SESSION["id"];
$name = $_SESSION["name"];
$email = $_SESSION["email"];
$position = $_SESSION['position'];
require("../conn.php");
require("components/c_header.php");
require("components/modal.php");

$prodname = $_GET["product"];
$prodinfo = $conn->query("SELECT * from tblproduct where prodname = '$prodname'");
$row = $prodinfo->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CDO Foodsphere E-Cart</title>
    <link rel="stylesheet" href="../css/myProf_Orders.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        body {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('../pics/bg.png');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            min-height: 100vh;
        }
    </style>
</head>

<body>
    <!-- ---------------------------------------ITEM_INFO--------------------------- -->
        <div class="container-fluid">
            <div class="container-fluid bg-light rounded">
                <div class="row p-3" style="min-height: 100px;">
                    <div class="col-sm-5 p-2 px-4 d-flex justify-content-center align-items-center rounded-start bg-secondary bg-opacity-25">
                        <div class="bg-light rounded shadow" style="width: clamp(10px, 30vw, 200px); height: auto;">
                            <?php
                                echo "<img src='../pics/$row[prodimage]' style='width: 100%; height: auto;'>";
                            ?>
                        </div>
                    </div>
                    <div class="col-sm-7 text-light rounded-end shadow bg-success p-3 px-4">
                        <form action="../sql/cart.php" method="post">
                        <?PHP
                            echo "
                            <div class='ps-3'>
                                <h1>$row[prodname]</h1>
                                <p>$row[proddesc]</p>
                            </div>
                            <hr>
                            <div class='ps-3'>
                                <table class='text-light w-50' cellpadding=10>
                                    <tr><td><b>Price</b></td><td>₱ $row[prodprice]</td></tr>
                                    <tr><td><b>Current Stock</b></td><td>$row[prodquantity] </td></tr>
                                    <tr><td><b>Quantity</b></td><td>";
                                    include('components/addQuan.php');
                                    echo"</td></tr>
                                </table>
                            </div>
                            <hr>
                            <div class='ps-3 text-end align-item-end' style='max-height: 100px;'>
                                <input type='submit' style='max-width: 200px; letter-spacing: 4px; color: white; font-size: clamp(8px,2vw,16px); border: 2px solid white;' value='ADD TO CART' class='bg-success rounded-pill fw-bold w-100'>
                            </div>
                            ";
                        ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</body>
<script src="../js/functions.js"></script>
<script>
    <?php
        if (isset($_GET["Successful"])) {
            echo "setTimeout(Hello, 250); function Hello() { alert('Profile Updated Successfully.'); }";
        } elseif (isset($_GET["Error"])) {
            $errorMessage = urldecode($_GET["Error"]);
            echo "setTimeout(Hello, 250); function Hello() { alert('An Error occurred: " . $errorMessage . "'); }";
        }
    ?>
</script>
</html>